package servlets;

import java.util.List;

public interface Formatter {
  public String format(List<Product> products);
}
