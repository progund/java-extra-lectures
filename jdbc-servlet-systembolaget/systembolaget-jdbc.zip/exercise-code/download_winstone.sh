#!/bin/bash

wget 'https://sourceforge.net/projects/winstone/files/latest/download?source=typ_redirect' -O winstone.jar
